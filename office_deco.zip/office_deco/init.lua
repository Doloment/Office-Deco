--###                     ###        ###              ###                     ######
--###                     ###        ###              ###                     ######
--        ###                     #########           ###     ###      ###          ###
--        ###                     #########           ###     ###      ###          ###
--###     #########       ###        ###              ###     ###      ###       #########
--###     #########       ###        ###              ###     ###      ###       #########
--###     ###      ###    ###        ###              ###     ###      ###    ###      ###
--###     ###      ###    ###        ###              ###     ###      ###    ###      ###
--###     ###      ###    ###        ###              ###        #########    ###      ###
--###     ###      ###    ###        ###              ###        #########    ###      ###
--###     ###      ###    ###           ###     ###      ###           ###       #########
--###     ###      ###    ###           ###     ###      ###           ###       #########

minetest.register_node("office_deco:box_copy_paper", {
	description = "box_copy_paper",
	drawtype = "mesh",
	mesh = "box_copy_paper.obj",
	drop = "office_deco:box_copy_paper",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"box_copy_paper.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:box_label_0", {
	description = "box_label_0",
	drawtype = "mesh",
	mesh = "box_large.obj",
	drop = "office_deco:box_label_0",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"box_label_0.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:box_label_a", {
	description = "box_label_a",
	drawtype = "mesh",
	mesh = "box_large.obj",
	drop = "office_deco:box_label_a",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"box_label_a.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:box_label_b", {
	description = "box_label_b",
	drawtype = "mesh",
	mesh = "box_large.obj",
	drop = "office_deco:box_label_b",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"box_label_b.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_0", {
	description = "box_label_0",
	drawtype = "mesh",
	mesh = "box_small.obj",
	drop = "office_deco:label_0",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_0.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_a", {
	description = "box_label_a",
	drawtype = "mesh",
	mesh = "box_small.obj",
	drop = "office_deco:label_a",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_a.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_b", {
	description = "box_label_b",
	drawtype = "mesh",
	mesh = "box_small.obj",
	drop = "office_deco:label_b",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_b.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_0_open", {
	description = "box_label_0_open",
	drawtype = "mesh",
	mesh = "box_small_open.obj",
	drop = "office_deco:label_0_open",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_0_open.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_a_open", {
	description = "box_label_a_open",
	drawtype = "mesh",
	mesh = "box_small_open.obj",
	drop = "office_deco:label_a_open",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_a_open.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:label_b_open", {
	description = "box_label_b_open",
	drawtype = "mesh",
	mesh = "box_small_open.obj",
	drop = "office_deco:label_b_open",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"label_b_open.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:cardboardbox", {
	description = "cardboardbox",
	drawtype = "mesh",
	mesh = "cardboardbox.obj",
	drop = "office_deco:cardboardbox",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"cardboardbox.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:chair_office", {
	description = "chair_office",
	drawtype = "mesh",
	mesh = "chair_office.obj",
	drop = "office_deco:chair_office",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"chair_office.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:circular_lamp", {
	description = "circular_lamp",
	drawtype = "mesh",
	mesh = "circular_lamp.obj",
	drop = "office_deco:circular_lamp",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"circular_lamp.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = true,
	node_box = {
		type = "wallmounted",
		wall_top    = {-0.4375, 0.4375, -0.3125, 0.4375, 0.5, 0.3125},
		wall_bottom = {-0.4375, -0.5, -0.3125, 0.4375, -0.4375, 0.3125},
		wall_side   = {-0.5, -0.3125, -0.4375, -0.4375, 0.3125, 0.4375},
	},
	sounds = default.node_sound_stone_defaults(),
	light_source = 15,
})

minetest.register_node("office_deco:clock", {
	description = "clock",
	drawtype = "mesh",
	mesh = "clock.obj",
	drop = "office_deco:clock",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"clock.png", "clock2.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "facedir",
	paramtype2 = "wallmounted",
	sunlight_propagates = true,
	is_ground_content = false,
	node_box = {
		type = "wallmounted",
		wall_top    = {-0.4375, 0.4375, -0.3125, 0.4375, 0.5, 0.3125},
		wall_bottom = {-0.4375, -0.5, -0.3125, 0.4375, -0.4375, 0.3125},
		wall_side   = {-0.5, -0.3125, -0.4375, -0.4375, 0.3125, 0.4375},
	},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:coffee_cup", {
	description = "coffee_cup",
	drawtype = "mesh",
	mesh = "coffee_cup.obj",
	drop = "office_deco:coffee_cup",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"coffee_cup.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.4, 0.3, 0.3, 0.3},
	node_box = {
		type = "fixed",
		fixed = {-0.4, -0.5, -0.4, 0.5, 0.3, 0.5},
		}
	},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:column_old", {
	description = "column_old",
	drawtype = "mesh",
	mesh = "column_old.obj",
	drop = "office_deco:column_old",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"column_old.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-1.0, -0.5, -1.0, 1.0, 7.5, 1.0},
	collision_box = {
		type = "fixed",
		fixed = {-1/0, -0/5, -1/0, 1/0, 7/5, 1/0},
		}
	},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("office_deco:column_spiral", {
	description = "column_spiral",
	drawtype = "mesh",
	mesh = "column_spiral.obj",
	drop = "office_deco:column_spiral",
	wield_scale = {x=0.5, y=0.5, z=0.5},
	tiles = {"column_spiral.png"},
	groups = {cracky = 1, level = 2},
	paramtype = "light",
	paramtype2 = "facedir",
	sunlight_propagates = true,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-1.0, -0.5, -1.0, 1.0, 3.5, 1.0},
	collision_box = {
		type = "fixed",
		fixed = {-1/0, -0/5, -1/0, 1/0, 7/5, 1/0},
		}
	},
	sounds = default.node_sound_stone_defaults(),
})
